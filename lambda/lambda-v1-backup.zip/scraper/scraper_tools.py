import requests, json, re, time, random, csv
import boto3
from bs4 import BeautifulSoup

#This function takes in the uuid for an individual sailor and returns true, if they exist already or false if they don't
def database_check(uuid):
    dydb = boto3.resource('dynamodb')
    table = dydb.Table("sailor-list")
    try:
        response = table.get_item(Key={"sailor-uuid":uuid})['Item']
    except:
        individualScrape(uuid)
        return False
    return True
    
def sailor_scrape(uuid):
    dydb = boto3.resource('dynamodb')
    table = dydb.Table("sailor-list")
    
    #readin the players profile html
    page = requests.get("https://scores.collegesailing.org/sailors/" + uuid + "/")
    content = BeautifulSoup(page.content, 'html.parser')
    
    #Setup a counter and a regattas dictionary.
    regattas = {}
    eventCounter = 0
    
    #Check to see if the sailor home field doesn't exist becuase they haven't sailed a regatta.
    home = content.find(id="content-header")
    if home is None:
        table.put_item(Item = {
            'sailor-uuid':uuid,
            'regatta-count':eventCounter,
            'regattas':regattas,
            'home':""
        })
        return
    home = home.find("ul").find_all("li")[1].find_all("span")[1].text

    #Find all the history tables, there should be one for each season, making sure they have sailed
    history = content.find_all(id="history")
    if history is None:
        table.put_item(Item = {
            'sailor-uuid':uuid,
            'regatta-count':eventCounter,
            'regattas':regattas,
            'home':home
        })
        return
    
    #Otherwise for every history table, we find all the events in that table.
    for season in history:
        seasonName = season.find('h3').find("a", href=True).get('href')
        seasonUuid = re.search(r'/(.*)/', seasonName).group(1)
        events = season.find('tbody')
        #People who have only sailed one event that is still currently in progress have a history table but no regattas so this checks to see if they have regattas sailed, it doesn't try to find them.
        if events is None:
            continue
        
        events = events.find_all('tr')
        for event in events:
            #For everyevent, we find the name, location, position and finish
            tdList = event.find_all('td')
            eventName = event.find_all('span')[0].text
            eventLocation = tdList[1].text
            eventPosition = tdList[3].text
            eventFinish = tdList[4].text
            eventCounter+=1
            regattas[seasonUuid+"-"+eventName] = {"location":eventLocation, "position":eventPosition, "finish":eventFinish}

    #Puts the end result of the scrape into the database.
    table.put_item(
        Item = {
        'sailor-uuid':uuid,
        'regatta-count':eventCounter,
        'regattas':regattas,
        'home': home,
    })

#this function takes in the uuid of a school and and returns all of the players on its current roster.
def rosterScrape(uuid):
        #readin the roster html
        page = requests.get("https://scores.collegesailing.org/schools/" + uuid + "/f19/roster")
        content = BeautifulSoup(page.content, 'html.parser')
        #setup empty list
        roster = []
        #find the tablebody and the find all the player rows
        table = content.find("tbody")
        players = table.find_all("tr")
        #for every player row, we get their href link which is the same as their uuid.
        for player in players:
            uuid = player.find("a", href = True).get('href')
            uuid = re.search(r'^/sailors/(.*)/$', uuid).group(1)
            #we append that uuid to the list
            roster.append(uuid)
        #return complete list
        return(roster)

#This takes regatta list dicationary and returns your percentage of regattas sailed in. 
def sailPercentage(regattaDict):
    #Check if the person hasn't sailed any regattas we return a None
    if regattaDict == {}:
        return None
    #Setting counter variables to 0
    sailedCounter = 0
    regattaCounter = 0
    #For every regatta we do a check to see if the person was not a reserve
    for regatta in regattaDict.values():
        #add one to the regatta counter
        regattaCounter = regattaCounter + 1;
        #If they weren't a reserve, add one to the sailedCounter
        if regatta["position"] != "Reserve":
            sailedCounter = sailedCounter + 1;
    if sailedCounter == 0:
        return 0
    #Return the percentage with a cast to float so it doesn't force iteger division.
    return float(sailedCounter)/float(regattaCounter)*100

#This method takes in the regatta dictionary and returns the average finish
def averageFinish(regattaDict):
    if regattaDict == {}:
        return None
    #Setting counters to 0
    finishCounter = 0
    finishTotal = 0

    #For every regatta, we want to get the respective finish
    for regatta in regattaDict.values():
        r_finish = regatta["finish"]
        #If they didn't get a result we continue
        if r_finish == "N/A":
            continue
        #Otherwise, we find all the matches for the DD/DD regex, this can have a problem with certain team race scoring formats
        #But is necessary for when crews sail in two divisions
        results = re.findall(r'[0-9]{1,2}/[0-9]{1,2}', r_finish)
        #For every match we count it as a finish and
        for result in results:
            finishCounter += 1
            #We add the left half of the fraction to the total.
            finishTotal += int(re.findall(r'([0-9]{1,2})/', result)[0])
    if finishCounter == 0:
        return None

    #We return the arethmetric mean of the finishes
    return float(finishTotal)/finishCounter


def locationTally(regattaDict):
    #All values that don't exist in the existing list
    newVenues = []

    #Get a list of current venues
    with open("venueList.csv", "rb+") as existing:
        currentVenues = [line[0] for line in csv.reader(existing, delimiter=',')]

    #For every venue in the persons  regatta dictonary, we check to see if it exists in the csv already or in the new venue list
    for venue in regattaDict.values():
        if venue["location"].encode('utf8') not in currentVenues and venue["location"].encode('utf8') not in newVenues:
            newVenues.append(venue["location"])
    #Opens the csv and writes all the new values to the csv.
    f = open("venueList.csv", "a+")
    for venue in newVenues:
        f.write(venue+",\n")
    f.close()

#Prints a pretty full scrape to the console
def fullScrape(uuid):
        print("-------------------------------------------------------------------------")
        print(uuid)
        regattaDict = individualScrape(uuid)
        print(regattaDict)
        print("Sail percentage: " + str(sailPercentage(regattaDict['regattas'])))
        print("Average finish: " + str(averageFinish(regattaDict['regattas'])))
        locationTally(regattaDict['regattas'])

