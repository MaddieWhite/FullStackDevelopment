#A config file for the database so all the settings are stored in one easily changable spot.
db_username = "admin"
db_password = "C6GbBlrJvigSLgatCNS5"
db_name = "indivstats"
db_host =  "sailstat.cgycbijj8kzf.us-east-1.rds.amazonaws.com"
