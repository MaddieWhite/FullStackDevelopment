## TODO: Use a database connection and pymysql to get top values for differnt columns.
